@echo off
setlocal
chcp 65001 >nul
set "PREVIEW_NODE=node"
where node >nul 2>nul
if errorlevel 1 (
  set "PREVIEW_NODE=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
)
"%PREVIEW_NODE%" "%~dp0scripts\preview.mjs"
if errorlevel 1 (
  echo Preview failed. Node.js 22 or later is required. Check the message above.
  pause
)
endlocal
