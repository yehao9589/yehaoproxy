# X-Panel Hub · 多面板管理台

集中管理多个 [xeefei/X-Panel](https://github.com/xeefei/X-Panel) 面板，提供状态查看、手动与定时备份、备份下载及任务记录。采用单个 Node.js Docker 容器，管理数据与备份保存在宿主机，无需额外部署数据库。

## 第一版功能

- 面板添加、编辑、移除、分组和搜索。
- 连接测试、状态总览及面板快捷入口。
- 单台或批量备份数据库，同时尝试导出 Xray 配置。
- 按北京时间每日定时备份，或按小时间隔备份。
- 按面板设置备份保留数量，查看备份时间、大小和 SHA-256。
- 后台任务记录、管理员登录、远端面板凭据加密存储。

定时任务运行在服务端，关闭网页后仍会执行。第一版不执行远端数据库恢复、面板升级或服务器重装。

## 宝塔 Docker 部署

以下命令在宝塔服务器的终端中执行，要求已安装 Docker 及 Docker Compose 插件。

### 1. 准备目录与配置

将项目源码上传至 `/www/wwwroot/x-panel-hub`，然后执行：

```sh
cd /www/wwwroot/x-panel-hub
cp .env.example .env
mkdir -p data
chown 1000:1000 data
chmod 700 data
chmod 600 .env
```

容器以镜像内的 `node` 用户（UID 1000）运行，宿主机 `data` 目录需要允许该用户写入。

用宝塔文件编辑器打开 `.env`，将 `ADMIN_PASSWORD` 替换为至少 12 个字符的随机密码。根据需要修改 `ADMIN_USERNAME`，通过宝塔 HTTPS 反向代理访问时保持 `COOKIE_SECURE=true`。

`ENCRYPTION_KEY` 可以留空：首次启动会自动生成密钥并保存在 `data` 目录。也可以通过以下命令生成 64 位十六进制密钥，填写到 `.env` 中：

```sh
docker run --rm node:22-alpine node -e "console.log(require('node:crypto').randomBytes(32).toString('hex'))"
```

选择一种方式后保留密钥；已有数据时不要直接更换，否则已保存的面板密码和 TOTP 密钥将无法解密。

### 2. 启动容器

```sh
docker compose up -d --build
docker compose ps
docker compose logs --tail=100 x-panel-hub
```

检查健康状态：

```sh
curl -fsS http://127.0.0.1:3080/healthz
```

默认端口只绑定在服务器的 `127.0.0.1:3080`，由宝塔网站代理访问。如发生端口冲突，可在 `.env` 中修改 `LOCAL_PORT`，并相应调整代理目标。

### 3. 配置宝塔反向代理

1. 在宝塔中新建网站，绑定管理台域名。
2. 为该网站配置 SSL 证书，并启用 HTTPS。
3. 添加反向代理，目标 URL 填写 `http://127.0.0.1:3080`。
4. 代理时保留访问者使用的 `Host`，并传递 `X-Forwarded-Proto`。管理台页面和 API 使用同一个域名，在网站根路径访问。

Nginx 代理位置的核心配置如下，可与宝塔生成的反向代理规则对应检查：

```nginx
location / {
    proxy_pass http://127.0.0.1:3080;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_read_timeout 120s;
}
```

然后通过 `https://你的管理台域名` 登录。`COOKIE_SECURE=true` 时登录 Cookie 只在 HTTPS 下发送；如果只做本机 HTTP 调试，应暂设为 `false` 并重建容器配置。

## 添加 X-Panel

在管理台添加面板，填写名称、分组、用户名、密码和完整登录入口。地址必须包含面板自定义访问路径，例如：

```text
https://panel.example.com:54321/my-secret-path/
```

填写访问路径的根入口，不要填入 `/panel`、`/login` 或 `/panel/api`。管理台会在该入口后拼接登录和备份接口。

先测试连接，再执行第一次手动备份，确认可以下载数据库后开启定时计划。每台面板独立维护登录会话，密码只在后端解密用于登录。

如果面板开启 2FA，长期无人值守的重新登录需要可用的 TOTP 密钥；一次性验证码不能一直用于自动登录。TOTP 密钥与密码同样加密保存。

管理台校验远端 HTTPS 证书。自签名证书或证书链错误会导致连接失败，请配置受信任的证书；第一版不提供忽略 TLS 校验的开关。

当前接入依据公开版本的 HTTP 接口：

- `POST {basePath}/login`
- `GET {basePath}/panel/api/server/status`
- `GET {basePath}/panel/api/server/getDb`
- `GET {basePath}/panel/api/server/getConfigJson`

基础版、Pro 版和不同历史版本可能存在差异，需通过实际面板测试连接与备份。初次状态响应可能正在预热，状态为空不代表备份接口不可用。

## 备份范围与保管

数据库导出保存 X-Panel 的数据库内容；Xray 配置导出单独保存，接口失败时应查看该次备份的提示。下载时会检查 SQLite 文件头并计算 SHA-256，这不能替代恢复演练。

这些备份不包含服务器系统文件、宿主机证书、Docker 编排和其他外部文件。恢复操作仍需按对应版本的 X-Panel 流程进行。

管理台自身的持久化数据位于项目的 `data/` 目录，包括面板记录、加密凭据、备份记录、任务记录及备份文件。建议定期将完整目录复制到另一处。创建一致副本时，可先停服务再归档：

```sh
docker compose stop x-panel-hub
tar -czf x-panel-hub-data.tar.gz data .env
docker compose start x-panel-hub
```

该归档包含管理密码配置和加密密钥，应作为敏感文件保管。如果使用 `.env` 内的 `ENCRYPTION_KEY`，恢复时也必须保留相同的密钥。恢复完整目录后确认 `data` 仍归 UID 1000 所有，再启动服务。

备份保留策略只应在新备份成功保存后清理旧文件。移除面板会停止其后续任务，历史备份可继续下载。

## 维护

修改 `.env` 后重新创建容器，使新环境变量生效：

```sh
docker compose up -d --force-recreate
```

更新源码后重新构建：

```sh
docker compose up -d --build
```

修改管理员密码后，使用新密码重新登录。保留 `data/` 和加密密钥，避免更新时丢失面板记录和历史备份。

## 演示与本地运行

演示模式使用明确标记的示例数据，不连接或修改真实面板，也不执行真实备份。可以先在 `.env` 中将 `DEMO_MODE=1`，再运行上面的 Docker 启动命令。通过 HTTPS 代理访问；本机 HTTP 预览时将 `COOKIE_SECURE=false`。

本机安装 Node.js 22 或更新版本后，可直接启动，项目无需安装 npm 依赖。

快速查看第一版界面：

```sh
node --env-file=.env.demo server.mjs
```

打开 `http://127.0.0.1:3080`。演示数据不会写入正式数据目录，也不会连接真实面板。

Windows 下也可以双击 `start-preview.cmd`：它会检测本机 3080 端口，在服务未运行时启动隐藏的后台演示进程，关闭启动窗口后仍可访问。电脑重启后可再次双击；重复启动不会占用第二个端口。日志位于 `.preview-data/preview.log`。该入口只启动只读演示，正式使用请按上面的 Docker 步骤部署。

Windows CMD 演示：

```bat
set DEMO_MODE=1
set COOKIE_SECURE=false
node server.mjs
```

Linux/macOS 演示：

```sh
DEMO_MODE=1 COOKIE_SECURE=false node server.mjs
```

默认访问 `http://127.0.0.1:3080`。本机正式模式需设置 `ADMIN_PASSWORD`，可通过环境变量修改 `HOST`、`PORT` 和 `DATA_DIR`。

运行自动化测试：

```sh
node --test test/*.test.mjs
```

自动化测试覆盖模拟面板接口；真实面板的网络、版本和凭据兼容性还需要部署后验证。
