import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';

const root = fileURLToPath(new URL('../', import.meta.url));
const url = 'http://127.0.0.1:3080';
const directory = path.join(root, '.preview-data');
const log = path.join(directory, 'preview.log');

function health() {
  return new Promise((resolve, reject) => {
    const request = http.get(`${url}/healthz`, response => {
      let body = '';
      response.setEncoding('utf8');
      response.on('data', chunk => {
        body += chunk;
        if (body.length > 4096) request.destroy(new Error('3080 端口返回了无法识别的响应'));
      });
      response.on('error', reject);
      response.on('end', () => {
        let result;
        try { result = JSON.parse(body); } catch { /* Report an occupied port below. */ }
        if (response.statusCode === 200 && result?.ok === true && typeof result.demo === 'boolean') {
          resolve(result);
        } else {
          reject(new Error('3080 端口已被其他服务占用，请先检查端口'));
        }
      });
    });
    request.setTimeout(2000, () => request.destroy(new Error('本机预览响应超时，请稍后重试')));
    request.on('error', error => error.code === 'ECONNREFUSED' ? resolve(null) : reject(error));
  });
}

async function main() {
  if (Number(process.versions.node.split('.')[0]) < 22) throw new Error('需要 Node.js 22 或更新版本');
  const current = await health();
  if (current) {
    console.log(`${current.demo ? '演示预览' : '正式管理台'}已经运行：${url}`);
    return;
  }
  fs.mkdirSync(directory, { recursive: true });
  const output = fs.openSync(log, 'a');
  let child;
  try {
    child = spawn(process.execPath, ['--env-file=.env.demo', 'server.mjs'], {
      cwd: root,
      detached: true,
      windowsHide: true,
      stdio: ['ignore', output, output],
      env: { ...process.env, DEMO_MODE: '1', HOST: '127.0.0.1', PORT: '3080', DATA_DIR: directory },
    });
    await new Promise((resolve, reject) => { child.once('spawn', resolve); child.once('error', reject); });
    child.unref();
  } finally {
    fs.closeSync(output);
  }
  for (let attempt = 0; attempt < 40; attempt += 1) {
    if (await health()) {
      console.log(`演示预览已在后台启动：${url}`);
      console.log('关闭启动窗口后仍可访问；电脑重启后可再次双击 start-preview.cmd。');
      return;
    }
    await new Promise(resolve => setTimeout(resolve, 250));
  }
  throw new Error(`预览未能就绪，请检查日志：${log}`);
}

try { await main(); }
catch (error) { console.error(error.message); process.exitCode = 1; }
