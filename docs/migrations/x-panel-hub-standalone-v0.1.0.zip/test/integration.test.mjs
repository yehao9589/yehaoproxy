import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { createApp } from '../server.mjs';
import { nextScheduledAt, normalizeSchedule } from '../lib/schedule.mjs';
import { totp } from '../lib/security.mjs';

const KEY = '12'.repeat(32);
const ADMIN_PASSWORD = 'correct-password-2026';
const database = Buffer.alloc(4096);
database.write('SQLite format 3\0', 0, 'binary');
database.writeUInt16BE(4096, 16);

async function listen(server) {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  return `http://127.0.0.1:${server.address().port}`;
}

async function mockPanel(t) {
  const state = { requests: [], loginCount: 0, failLogin: false, expireOnce: false, alwaysUnauthorized: false, dbMode: 'good', statusObj: { cpu: 18.5, mem: { current: 512, total: 1024 }, netIO: { up: 100, down: 50 }, xray: { state: 'running' } }, configObj: { inbounds: [], outbounds: [{ protocol: 'freedom' }] }, configFails: false, delayDb: 0 };
  const server = http.createServer(async (request, response) => {
    const chunks = [];
    for await (const chunk of request) chunks.push(chunk);
    state.requests.push({ url: request.url, method: request.method, headers: request.headers, body: Buffer.concat(chunks).toString() });
    const send = (status, body, headers = {}) => { response.writeHead(status, { 'Content-Type': 'application/json', ...headers }); response.end(JSON.stringify(body)); };
    if (request.url === '/secret/login') {
      state.loginCount += 1;
      if (state.failLogin) return send(200, { success: false, msg: 'bad login' });
      return send(200, { success: true }, { 'Set-Cookie': ['3x-ui=test-session; Path=/secret/; HttpOnly', 'auxiliary=value; Path=/secret/'] });
    }
    if (!request.headers.cookie?.includes('3x-ui=test-session') || state.alwaysUnauthorized || state.expireOnce) {
      state.expireOnce = false;
      return send(401, { success: false });
    }
    if (request.url === '/secret/panel/api/server/status') return send(200, { success: true, obj: state.statusObj });
    if (request.url === '/secret/panel/api/server/getConfigJson') return send(state.configFails ? 500 : 200, { success: !state.configFails, obj: state.configObj });
    if (request.url === '/secret/panel/api/server/getDb') {
      if (state.delayDb) await new Promise(resolve => setTimeout(resolve, state.delayDb));
      if (state.dbMode === 'html') { response.writeHead(200, { 'Content-Type': 'text/html' }); return response.end('<html>login required</html>'); }
      if (state.dbMode === 'json') return send(200, { success: false, msg: 'backup failed' });
      if (state.dbMode === 'truncated') { response.writeHead(200); return response.end('SQLite format 3\0'); }
      response.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Content-Disposition': 'attachment; filename="x-ui.db"' });
      return response.end(database);
    }
    send(404, { success: false });
  });
  const origin = await listen(server);
  t.after(async () => {
    await new Promise(resolve => { server.close(resolve); server.closeAllConnections(); });
  });
  return { state, origin };
}

async function harness(t, extra = {}) {
  const temporaryRoot = fileURLToPath(new URL('../.test-data/', import.meta.url));
  await fs.mkdir(temporaryRoot, { recursive: true });
  const directory = await fs.mkdtemp(path.join(temporaryRoot, 'session-'));
  const apps = [];
  t.after(async () => {
    for (const app of apps.reverse()) await app.close();
    await fs.rm(directory, { recursive: true, force: true });
  });
  async function launch(overrides = {}) {
    const app = createApp({ dataDir: directory, encryptionKey: KEY, adminUsername: 'admin', adminPassword: ADMIN_PASSWORD, startScheduler: false, remoteTimeout: 3000, ...extra, ...overrides });
    apps.push(app);
    const address = await app.listen(0, '127.0.0.1');
    const origin = `http://127.0.0.1:${address.port}`;
    let cookie = '';
    async function request(route, method = 'GET', body, headers = {}) {
      return fetch(`${origin}${route}`, { method, headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), ...(cookie ? { Cookie: cookie } : {}), ...headers }, ...(body !== undefined ? { body: JSON.stringify(body) } : {}) });
    }
    const response = await request('/api/auth/login', 'POST', { username: 'admin', password: ADMIN_PASSWORD });
    assert.equal(response.status, 200);
    const sessionCookie = response.headers.getSetCookie()[0];
    cookie = sessionCookie.split(';', 1)[0];
    return { app, origin, request, cookie, sessionCookie };
  }
  return { directory, launch };
}

async function addPanel(client, origin, schedule = { enabled: false }) {
  const response = await client.request('/api/panels', 'POST', { name: '测试面板', group: '测试', baseUrl: `${origin}/secret`, username: 'remote-user', password: 'remote-password', schedule });
  assert.equal(response.status, 201);
  return (await response.json()).panel;
}

async function backup(client, panel) {
  const response = await client.request(`/api/panels/${panel.id}/backup`, 'POST', {});
  assert.equal(response.status, 202);
  await client.app.waitForIdle();
  return client.app.stateSnapshot();
}

test('自定义路径、Cookie、状态、数据库与配置下载串通，凭据加密持久化', async t => {
  const remote = await mockPanel(t);
  const { launch, directory } = await harness(t);
  const client = await launch();
  const panel = await addPanel(client, remote.origin);
  const check = await client.request(`/api/panels/${panel.id}/check`, 'POST', {});
  assert.equal(check.status, 200);
  assert.equal((await check.json()).panel.status.metrics.cpu, 18.5);
  const state = await backup(client, panel);
  assert.equal(state.backups.length, 1);
  assert.equal(state.backups[0].sha256, createHash('sha256').update(database).digest('hex'));
  assert.equal(state.backups[0].hasConfig, true);
  assert.equal(state.jobs.filter(job => job.status === 'success').length, 2);
  const download = await client.request(`/api/backups/${state.backups[0].id}/download`);
  assert.deepEqual(Buffer.from(await download.arrayBuffer()), database);
  const downloadHead = await client.request(`/api/backups/${state.backups[0].id}/download`, 'HEAD');
  assert.equal(downloadHead.status, 200);
  assert.equal(Number(downloadHead.headers.get('content-length')), database.length);
  assert.equal((await downloadHead.arrayBuffer()).byteLength, 0);
  const config = await client.request(`/api/backups/${state.backups[0].id}/download?kind=config`);
  assert.deepEqual(await config.json(), remote.state.configObj);
  assert.equal(remote.state.loginCount, 1);
  for (const request of remote.state.requests) {
    assert.ok(request.url.startsWith('/secret/'));
    assert.equal(request.headers['x-requested-with'], 'XMLHttpRequest');
    if (!request.url.endsWith('/login')) assert.ok(request.headers.cookie.includes('3x-ui=test-session'));
  }
  const form = new URLSearchParams(remote.state.requests[0].body);
  assert.equal(form.get('username'), 'remote-user');
  assert.equal(form.get('password'), 'remote-password');
  const persisted = await fs.readFile(path.join(directory, 'state.json'), 'utf8');
  assert.ok(!persisted.includes('remote-password'));
  assert.ok(!persisted.includes('remote-user'));
  const publicState = JSON.stringify(state);
  assert.ok(!publicState.includes('remote-password'));
  assert.ok(!publicState.includes('credentials'));
});

test('HTTP 200 的登录失败不会被判为成功，会话过期至多重登录一次', async t => {
  const remote = await mockPanel(t);
  const { launch } = await harness(t);
  const client = await launch();
  const panel = await addPanel(client, remote.origin);
  remote.state.failLogin = true;
  await client.request(`/api/panels/${panel.id}/check`, 'POST', {});
  assert.equal(client.app.stateSnapshot().panels[0].status.online, false);
  assert.match(client.app.stateSnapshot().jobs[0].message, /登录失败/);
  remote.state.failLogin = false;
  remote.state.expireOnce = true;
  await client.request(`/api/panels/${panel.id}/check`, 'POST', {});
  assert.equal(client.app.stateSnapshot().panels[0].status.online, true);
  assert.equal(remote.state.loginCount, 3);
  const before = remote.state.loginCount;
  remote.state.alwaysUnauthorized = true;
  await client.request(`/api/panels/${panel.id}/check`, 'POST', {});
  assert.equal(remote.state.loginCount - before, 1);
  assert.equal(client.app.stateSnapshot().panels[0].status.online, false);
});

test('HTML、JSON、截断数据库均不产生成功记录，也不会清理上一份备份', async t => {
  const remote = await mockPanel(t);
  const { launch, directory } = await harness(t);
  const client = await launch();
  const panel = await addPanel(client, remote.origin, { enabled: false, retain: 1 });
  const original = (await backup(client, panel)).backups[0];
  for (const mode of ['html', 'json', 'truncated']) {
    remote.state.dbMode = mode;
    const state = await backup(client, panel);
    assert.equal(state.backups.length, 1);
    assert.equal(state.backups[0].id, original.id);
    assert.equal(state.jobs[0].status, 'error');
    const download = await client.request(`/api/backups/${original.id}/download`);
    assert.deepEqual(Buffer.from(await download.arrayBuffer()), database);
  }
  const files = await fs.readdir(path.join(directory, 'backups'));
  assert.equal(files.filter(name => name.endsWith('.db')).length, 1);
  assert.equal(files.filter(name => name.endsWith('.tmp')).length, 0);
  remote.state.dbMode = 'good';
  const newState = await backup(client, panel);
  assert.equal(newState.backups.length, 1);
  assert.notEqual(newState.backups[0].id, original.id);
  assert.equal((await client.request(`/api/backups/${original.id}/download`)).status, 404);
});

test('计划重启后持久化，未到北京时间不早跑，错过多轮只追补一次', async t => {
  const remote = await mockPanel(t);
  let currentTime = Date.parse('2026-10-29T18:59:00Z');
  const { launch } = await harness(t, { now: () => currentTime });
  let client = await launch();
  const panel = await addPanel(client, remote.origin, { enabled: true, kind: 'daily', time: '03:00', retain: 7 });
  assert.equal(panel.nextBackupAt, '2026-10-29T19:00:00.000Z');
  await client.app.close();
  client = await launch();
  assert.equal(client.app.stateSnapshot().panels[0].nextBackupAt, panel.nextBackupAt);
  currentTime += 59_000;
  client.app.tick();
  await client.app.waitForIdle();
  assert.equal(client.app.stateSnapshot().backups.length, 0);
  currentTime += 1000;
  client.app.tick();
  client.app.tick();
  await client.app.waitForIdle();
  assert.equal(client.app.stateSnapshot().backups.length, 1);
  assert.equal(client.app.stateSnapshot().jobs[0].trigger, 'schedule');
  assert.equal(client.app.stateSnapshot().panels[0].nextBackupAt, '2026-10-30T19:00:00.000Z');
  currentTime += 3 * 86400_000;
  client.app.tick();
  await client.app.waitForIdle();
  assert.equal(client.app.stateSnapshot().backups.length, 2);
  assert.ok(Date.parse(client.app.stateSnapshot().panels[0].nextBackupAt) > currentTime);
});

test('状态缓存预热 obj:null 仍然在线，配置导出失败保留有效数据库', async t => {
  const remote = await mockPanel(t);
  remote.state.statusObj = null;
  const { launch } = await harness(t);
  const client = await launch();
  const panel = await addPanel(client, remote.origin);
  await client.request(`/api/panels/${panel.id}/check`, 'POST', {});
  const status = client.app.stateSnapshot().panels[0].status;
  assert.equal(status.online, true);
  assert.equal(status.metrics, null);
  assert.match(client.app.stateSnapshot().jobs[0].message, /等待/);
  remote.state.configFails = true;
  const state = await backup(client, panel);
  assert.equal(state.backups.length, 1);
  assert.equal(state.backups[0].hasConfig, false);
  assert.match(state.backups[0].warning, /配置导出失败/);
  assert.equal(state.jobs[0].status, 'success');
});

test('同面板备份互斥，删除面板保留备份，重启中断任务明确标记', async t => {
  const remote = await mockPanel(t);
  remote.state.delayDb = 100;
  const { launch } = await harness(t);
  let client = await launch();
  const panel = await addPanel(client, remote.origin);
  assert.equal((await client.request(`/api/panels/${panel.id}/backup`, 'POST', {})).status, 202);
  assert.equal((await client.request(`/api/panels/${panel.id}/backup`, 'POST', {})).status, 409);
  assert.equal((await client.request(`/api/panels/${panel.id}`, 'DELETE')).status, 409);
  await client.app.waitForIdle();
  assert.equal((await client.request(`/api/panels/${panel.id}`, 'DELETE')).status, 200);
  assert.equal(client.app.stateSnapshot().backups.length, 1);
  client.app.store.mutate(state => { state.jobs.unshift({ id: 'interrupted', status: 'running' }); });
  await client.app.close();
  client = await launch();
  assert.equal(client.app.stateSnapshot().panels.length, 0);
  assert.equal(client.app.stateSnapshot().backups.length, 1);
  assert.equal(client.app.stateSnapshot().jobs[0].status, 'error');
  assert.match(client.app.stateSnapshot().jobs[0].message, /重启/);
});

test('管理员认证、来源校验、限流和只读演示边界', async t => {
  const { launch } = await harness(t);
  const previousSecureCookie = process.env.COOKIE_SECURE;
  let client;
  try {
    process.env.COOKIE_SECURE = 'true';
    client = await launch();
  } finally {
    if (previousSecureCookie === undefined) delete process.env.COOKIE_SECURE;
    else process.env.COOKIE_SECURE = previousSecureCookie;
  }
  assert.match(client.sessionCookie, /; Secure(?:;|$)/);
  const anonymous = await fetch(`${client.origin}/api/state`);
  assert.equal(anonymous.status, 401);
  const me = await client.request('/api/auth/me');
  assert.equal((await me.json()).authenticated, true);
  const crossSite = await client.request('/api/panels', 'POST', {}, { Origin: 'https://evil.example' });
  assert.equal(crossSite.status, 403);
  for (let index = 0; index < 8; index += 1) assert.equal((await client.request('/api/auth/login', 'POST', { username: 'admin', password: 'wrong' })).status, 401);
  assert.equal((await client.request('/api/auth/login', 'POST', { username: 'admin', password: ADMIN_PASSWORD })).status, 429);
  assert.equal((await client.request('/api/auth/logout', 'POST', {})).status, 200);
  assert.equal((await client.request('/api/state')).status, 401);
  let demoNow = Date.parse('2026-10-29T18:59:00Z');
  const demo = createApp({ demo: true, startScheduler: false, now: () => demoNow });
  t.after(() => demo.close());
  const address = await demo.listen(0, '127.0.0.1');
  const demoOrigin = `http://127.0.0.1:${address.port}`;
  const state = await fetch(`${demoOrigin}/api/state`).then(response => response.json());
  assert.equal(state.panels.length, 6);
  assert.ok(state.panels.every(panel => panel.demo));
  assert.ok(state.backups.every(item => item.demo));
  assert.equal(state.panels[0].nextBackupAt, '2026-10-29T19:00:00.000Z');
  demoNow += 90_000;
  const refreshed = await fetch(`${demoOrigin}/api/state`).then(response => response.json());
  assert.deepEqual(refreshed, state, '演示数据时间应固定在服务启动时，不随轮询漂移');
  assert.equal((await fetch(`${demoOrigin}/api/backup-all`, { method: 'POST' })).status, 409);
});

test('TOTP 标准向量与间隔调度，非法计划和错误密钥不会默默重置数据', async t => {
  assert.equal(totp('GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ', 59_000), '287082');
  const schedule = normalizeSchedule({ enabled: true, kind: 'interval', hours: 6 });
  assert.equal(nextScheduledAt(schedule, 0), '1970-01-01T06:00:00.000Z');
  assert.throws(() => normalizeSchedule({ time: '25:60' }), /HH:mm/);
  assert.throws(() => normalizeSchedule({ retain: 0 }), /1–100/);
  const remote = await mockPanel(t);
  const { launch, directory } = await harness(t);
  const client = await launch();
  await addPanel(client, remote.origin);
  assert.throws(() => createApp({ dataDir: directory, encryptionKey: '34'.repeat(32), adminPassword: ADMIN_PASSWORD, startScheduler: false }), /无法解密/);
  assert.equal(client.app.stateSnapshot().panels.length, 1);
});
