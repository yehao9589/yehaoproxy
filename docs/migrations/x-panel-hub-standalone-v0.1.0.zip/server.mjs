import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { randomBytes, randomUUID, createHash } from 'node:crypto';
import { Store } from './lib/store.mjs';
import { normalizeTotpSecret, passwordVerifier } from './lib/security.mjs';
import { normalizeBaseUrl, RemoteClient } from './lib/remote.mjs';
import { nextScheduledAt, normalizeSchedule } from './lib/schedule.mjs';
import { demoState } from './lib/demo.mjs';

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

class Queue {
  constructor(concurrency = 3) { this.concurrency = concurrency; this.active = 0; this.pending = []; this.waiters = []; }
  add(task) { this.pending.push(task); this.drain(); }
  drain() {
    while (this.active < this.concurrency && this.pending.length) {
      const task = this.pending.shift();
      this.active += 1;
      Promise.resolve().then(task).catch(error => console.error('后台任务异常:', error.message)).finally(() => {
        this.active -= 1;
        this.drain();
        if (!this.active && !this.pending.length) this.waiters.splice(0).forEach(resolve => resolve());
      });
    }
  }
  idle() { return !this.active && !this.pending.length ? Promise.resolve() : new Promise(resolve => this.waiters.push(resolve)); }
}

function text(value, label, max = 120, required = false) {
  if (value === undefined || value === null) value = '';
  if (typeof value !== 'string') throw new HttpError(400, `${label}格式无效`);
  const result = value.trim();
  if (result.length > max || (required && !result)) throw new HttpError(400, `${label}${required ? '不能为空，且' : ''}不能超过 ${max} 个字符`);
  return result;
}

async function jsonBody(request) {
  if (!String(request.headers['content-type'] || '').toLowerCase().startsWith('application/json')) {
    throw new HttpError(415, '请求必须使用 application/json');
  }
  const chunks = [];
  let length = 0;
  for await (const chunk of request) {
    length += chunk.length;
    if (length > 64 * 1024) throw new HttpError(413, '请求内容过大');
    chunks.push(chunk);
  }
  try {
    const value = JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}');
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error();
    return value;
  } catch { throw new HttpError(400, '请求 JSON 格式无效'); }
}

export function createApp(options = {}) {
  const demo = options.demo ?? process.env.DEMO_MODE === '1';
  const now = options.now || Date.now;
  const demoAnchor = demo ? now() : null;
  const adminUsername = options.adminUsername ?? process.env.ADMIN_USERNAME ?? 'admin';
  const adminPassword = options.adminPassword ?? process.env.ADMIN_PASSWORD ?? '';
  if (!demo && (typeof adminPassword !== 'string' || adminPassword.length < 12)) {
    throw new Error('请设置至少 12 个字符的 ADMIN_PASSWORD；仅预览界面可使用 DEMO_MODE=1');
  }
  if (!adminUsername || adminUsername.length > 120) throw new Error('ADMIN_USERNAME 无效');
  const checkPassword = demo ? () => false : passwordVerifier(adminPassword);
  const dataDirectory = options.dataDir ?? process.env.DATA_DIR ?? path.resolve('data');
  const store = demo ? null : new Store(dataDirectory, options.encryptionKey ?? process.env.ENCRYPTION_KEY);
  const secureCookie = options.cookieSecure ?? /^(1|true)$/i.test(String(process.env.COOKIE_SECURE || '').trim());
  const publicOrigin = options.publicOrigin ?? process.env.PUBLIC_ORIGIN ?? '';
  const publicDirectory = options.publicDir ?? fileURLToPath(new URL('./public/', import.meta.url));
  const sessions = new Map();
  const loginAttempts = new Map();
  const clients = new Map();
  const checks = new Map();
  const backupLocks = new Set();
  const queue = new Queue(options.concurrency ?? 3);
  const sessionLength = 8 * 3_600_000;
  let scheduler;
  let statusTimer;
  let closing = false;

  function panelById(id) {
    const panel = store.state.panels.find(item => item.id === id);
    if (!panel) throw new HttpError(404, '面板不存在');
    return panel;
  }

  function publicPanel(panel) {
    const credentials = store.credentials(panel);
    return {
      id: panel.id, name: panel.name, baseUrl: panel.baseUrl, group: panel.group,
      username: credentials.username, hasPassword: Boolean(credentials.password), hasTotp: Boolean(credentials.totpSecret),
      schedule: panel.schedule, nextBackupAt: panel.nextBackupAt, lastBackupAt: panel.lastBackupAt,
      status: panel.status, createdAt: panel.createdAt,
    };
  }

  function publicBackup(backup) {
    const { dbFile, configFile, ...result } = backup;
    return { ...result, hasConfig: Boolean(configFile) };
  }

  function stateSnapshot() {
    if (demo) return demoState(demoAnchor);
    return {
      panels: store.state.panels.map(publicPanel), backups: store.state.backups.map(publicBackup), jobs: store.state.jobs,
      settings: { timezone: 'Asia/Shanghai', backupDirectory: store.backupDirectory, demo: false, maxBackupMB: 256, version: '0.1.0' },
    };
  }

  function getClient(panel) {
    if (!clients.has(panel.id)) clients.set(panel.id, new RemoteClient(panel, store.credentials(panel), {
      fetchImpl: options.fetchImpl, timeout: options.remoteTimeout, maxBackupBytes: options.maxBackupBytes, now,
    }));
    return clients.get(panel.id);
  }

  function createJob(panel, kind, trigger) {
    const job = { id: randomUUID(), panelId: panel.id, panelName: panel.name, kind, trigger, status: 'running', startedAt: new Date(now()).toISOString(), finishedAt: null, message: '等待执行' };
    store.mutate(state => { state.jobs.unshift(job); state.jobs = state.jobs.filter((item, index) => index < 200 || item.status === 'running'); });
    return job.id;
  }

  function finishJob(id, status, message) {
    store.mutate(state => {
      const job = state.jobs.find(item => item.id === id);
      if (job) Object.assign(job, { status, message, finishedAt: new Date(now()).toISOString() });
    });
  }

  function checkPanel(id, trigger = 'manual', recordJob = true) {
    if (checks.has(id)) return checks.get(id);
    const panel = panelById(id);
    const jobId = recordJob ? createJob(panel, 'check', trigger) : null;
    let resolveTask;
    const task = new Promise(resolve => { resolveTask = resolve; });
    checks.set(id, task);
    queue.add(async () => {
      try {
        const metrics = await getClient(panel).status();
        store.mutate(state => {
          const item = state.panels.find(value => value.id === id);
          if (item) item.status = { online: true, checkedAt: new Date(now()).toISOString(), error: null, metrics: metrics ?? null };
        });
        if (jobId) finishJob(jobId, 'success', metrics === null ? '连接成功，等待面板状态缓存生成' : '面板连接正常');
      } catch (error) {
        store.mutate(state => {
          const item = state.panels.find(value => value.id === id);
          if (item) item.status = { online: false, checkedAt: new Date(now()).toISOString(), error: error.message, metrics: item.status?.metrics ?? null };
        });
        if (jobId) finishJob(jobId, 'error', error.message);
      } finally {
        checks.delete(id);
        const current = store.state.panels.find(item => item.id === id);
        resolveTask(current ? publicPanel(current) : null);
      }
    });
    return task;
  }

  function pruneBackups(panelId, retain) {
    const candidates = store.state.backups.filter(item => item.panelId === panelId).slice(retain);
    if (!candidates.length) return;
    // Persist removal first: a filesystem failure leaves an unlisted orphan, never a dangling download.
    const ids = new Set(candidates.map(item => item.id));
    store.mutate(state => { state.backups = state.backups.filter(item => !ids.has(item.id)); });
    for (const backup of candidates) {
      try {
        fs.rmSync(store.backupPath(backup.dbFile), { force: true });
        if (backup.configFile) fs.rmSync(store.backupPath(backup.configFile), { force: true });
      } catch { console.error('旧备份文件清理失败，请检查备份目录权限'); }
    }
  }

  function startBackup(id, trigger = 'manual') {
    const panel = panelById(id);
    if (backupLocks.has(id)) throw new HttpError(409, '该面板已有备份任务正在运行或等待执行');
    backupLocks.add(id);
    let jobId;
    try { jobId = createJob(panel, 'backup', trigger); }
    catch (error) { backupLocks.delete(id); throw error; }
    queue.add(async () => {
      const backupId = randomUUID();
      const temporary = store.backupPath(`${backupId}.tmp`);
      const database = store.backupPath(`${backupId}.db`);
      const configurationFile = store.backupPath(`${backupId}.json`);
      let committed = false;
      try {
        const client = getClient(panel);
        const result = await client.downloadDatabase(temporary);
        let configuration;
        let warning = null;
        try { configuration = await client.configuration(); }
        catch (error) { warning = `数据库已保存；Xray 配置导出失败：${error.message}`; }
        fs.renameSync(temporary, database);
        if (configuration !== undefined) fs.writeFileSync(configurationFile, `${JSON.stringify(configuration, null, 2)}\n`, { mode: 0o600, flag: 'wx' });
        const createdAt = new Date(now()).toISOString();
        const backup = { id: backupId, panelId: id, panelName: panel.name, createdAt, ...result, dbFile: `${backupId}.db`, configFile: configuration !== undefined ? `${backupId}.json` : null, warning };
        store.mutate(state => {
          state.backups.unshift(backup);
          const current = state.panels.find(item => item.id === id);
          if (current) current.lastBackupAt = createdAt;
        });
        committed = true;
        pruneBackups(id, panel.schedule.retain);
        finishJob(jobId, 'success', warning || '数据库与 Xray 配置已保存，已校验 SQLite 文件头并记录 SHA-256');
      } catch (error) {
        finishJob(jobId, 'error', error.message);
      } finally {
        for (const filename of committed ? [temporary] : [temporary, database, configurationFile]) {
          try { fs.rmSync(filename, { force: true }); } catch { /* A failed file is never included in backup records. */ }
        }
        backupLocks.delete(id);
      }
    });
    return jobId;
  }

  function tick() {
    if (demo || closing) return;
    for (const panel of [...store.state.panels]) {
      if (!panel.schedule.enabled || !panel.nextBackupAt || new Date(panel.nextBackupAt).getTime() > now() || backupLocks.has(panel.id)) continue;
      store.mutate(state => {
        const current = state.panels.find(item => item.id === panel.id);
        if (current) current.nextBackupAt = nextScheduledAt(current.schedule, now());
      });
      startBackup(panel.id, 'schedule');
    }
    for (const [token, session] of sessions) if (session.expiresAt <= now()) sessions.delete(token);
    for (const [ip, attempt] of loginAttempts) if (attempt.until <= now()) loginAttempts.delete(ip);
  }

  function cookie(value, maxAge) {
    return `xpm_session=${value}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAge}${secureCookie ? '; Secure' : ''}`;
  }

  function sessionFrom(request) {
    const token = String(request.headers.cookie || '').split(';').map(part => part.trim()).find(part => part.startsWith('xpm_session='))?.slice(12);
    if (!token) return null;
    const hash = createHash('sha256').update(token).digest('hex');
    const session = sessions.get(hash);
    if (!session || session.expiresAt <= now()) { sessions.delete(hash); return null; }
    return { ...session, hash };
  }

  function verifyOrigin(request) {
    const origin = request.headers.origin;
    if (request.headers['sec-fetch-site'] === 'cross-site') throw new HttpError(403, '拒绝跨站请求');
    if (!origin) return;
    let allowed = false;
    try { allowed = publicOrigin ? origin === new URL(publicOrigin).origin : new URL(origin).host === request.headers.host; } catch { /* Reject malformed origins. */ }
    if (!allowed) throw new HttpError(403, '请求来源不匹配，请检查反向代理 Host 配置');
  }

  function json(response, status, body, headers = {}) {
    response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
    response.end(JSON.stringify(body));
  }

  function normalizePanel(input, previous) {
    const credentials = previous ? store.credentials(previous) : { username: '', password: '', totpSecret: '' };
    const name = text(input.name ?? previous?.name, '面板名称', 80, true);
    const group = text(input.group ?? previous?.group ?? '', '分组', 40);
    const username = text(input.username ?? credentials.username, '用户名', 120, true);
    if (input.password !== undefined && typeof input.password !== 'string') throw new HttpError(400, '密码格式无效');
    const password = input.password || credentials.password;
    if (!password || password.length > 1024) throw new HttpError(400, '请输入面板密码（最多 1024 个字符）');
    let baseUrl;
    let schedule;
    let totpSecret;
    try {
      baseUrl = normalizeBaseUrl(input.baseUrl ?? previous?.baseUrl);
      if (baseUrl.length > 2048) throw new Error('面板地址过长');
      schedule = normalizeSchedule(input.schedule, previous?.schedule);
      // Omitted or empty secret preserves an existing secret. Explicit clearTotp removes it.
      totpSecret = input.clearTotp === true ? '' : input.totpSecret ? normalizeTotpSecret(input.totpSecret) : credentials.totpSecret;
    } catch (error) { throw new HttpError(400, error.message); }
    const scheduleChanged = !previous || ['enabled', 'kind', 'time', 'hours'].some(key => schedule[key] !== previous.schedule[key]);
    const connectionChanged = !previous || previous.baseUrl !== baseUrl || username !== credentials.username || password !== credentials.password || totpSecret !== credentials.totpSecret;
    return {
      id: previous?.id || randomUUID(), name, group, baseUrl, credentials: store.seal({ username, password, totpSecret }), schedule,
      nextBackupAt: scheduleChanged ? nextScheduledAt(schedule, now()) : previous.nextBackupAt,
      lastBackupAt: previous?.lastBackupAt ?? null, createdAt: previous?.createdAt ?? new Date(now()).toISOString(),
      status: connectionChanged ? { online: null, checkedAt: null, error: null, metrics: null } : previous.status,
    };
  }

  const staticFiles = new Map([
    ['/', ['index.html', 'text/html; charset=utf-8']], ['/index.html', ['index.html', 'text/html; charset=utf-8']],
    ['/app.js', ['app.js', 'text/javascript; charset=utf-8']], ['/styles.css', ['styles.css', 'text/css; charset=utf-8']],
    ['/favicon.svg', ['favicon.svg', 'image/svg+xml']],
  ]);

  const server = http.createServer(async (request, response) => {
    response.setHeader('X-Content-Type-Options', 'nosniff');
    response.setHeader('Referrer-Policy', 'same-origin');
    response.setHeader('X-Frame-Options', 'DENY');
    response.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; font-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'");
    let url;
    try {
      url = new URL(request.url, 'http://localhost');
      const pathname = url.pathname;
      const method = request.method;
      if (pathname === '/healthz' && method === 'GET') return json(response, 200, { ok: true, demo });
      if (!pathname.startsWith('/api/')) {
        const entry = staticFiles.get(pathname);
        if (!entry || !['GET', 'HEAD'].includes(method)) throw new HttpError(404, '页面不存在');
        const filename = path.join(publicDirectory, entry[0]);
        if (!fs.existsSync(filename)) throw new HttpError(404, '前端文件尚未准备完成');
        const content = fs.readFileSync(filename);
        response.writeHead(200, { 'Content-Type': entry[1], 'Content-Length': content.length, 'Cache-Control': 'no-cache' });
        return response.end(method === 'HEAD' ? undefined : content);
      }
      if (!['GET', 'HEAD'].includes(method)) verifyOrigin(request);
      if (pathname === '/api/auth/me' && method === 'GET') {
        const session = sessionFrom(request);
        return json(response, 200, { authenticated: demo || Boolean(session), demo, username: demo ? '演示管理员' : session?.username ?? null });
      }
      if (pathname === '/api/auth/login' && method === 'POST') {
        if (demo) return json(response, 200, { authenticated: true, demo: true, username: '演示管理员' });
        const body = await jsonBody(request);
        const ip = request.socket.remoteAddress || 'unknown';
        let attempt = loginAttempts.get(ip);
        if (attempt?.until > now() && attempt.failures >= 8) throw new HttpError(429, '登录失败次数过多，请在 15 分钟后重试');
        if (!attempt || attempt.until <= now()) attempt = { failures: 0, until: now() + 15 * 60_000 };
        const valid = typeof body.password === 'string' && body.password.length <= 1024 && checkPassword(body.password);
        if (!valid || body.username !== adminUsername) {
          attempt.failures += 1;
          loginAttempts.set(ip, attempt);
          if (loginAttempts.size > 1000) loginAttempts.delete(loginAttempts.keys().next().value);
          throw new HttpError(401, '用户名或密码错误');
        }
        loginAttempts.delete(ip);
        const token = randomBytes(32).toString('hex');
        if (sessions.size >= 100) sessions.delete(sessions.keys().next().value);
        sessions.set(createHash('sha256').update(token).digest('hex'), { username: adminUsername, expiresAt: now() + sessionLength });
        return json(response, 200, { authenticated: true, demo: false, username: adminUsername }, { 'Set-Cookie': cookie(token, 8 * 3600) });
      }
      if (pathname === '/api/auth/logout' && method === 'POST') {
        const session = sessionFrom(request);
        if (session) sessions.delete(session.hash);
        return json(response, 200, { message: '已退出登录' }, { 'Set-Cookie': cookie('', 0) });
      }
      if (!demo && !sessionFrom(request)) throw new HttpError(401, '请先登录管理台');
      if (pathname === '/api/state' && method === 'GET') return json(response, 200, stateSnapshot());
      if (demo) throw new HttpError(409, '当前是只读演示，不能连接真实面板、执行备份或修改数据；正式模式部署后即可使用');
      if (pathname === '/api/panels' && method === 'POST') {
        const panel = normalizePanel(await jsonBody(request));
        store.mutate(state => { state.panels.push(panel); });
        if (options.backgroundChecks !== false && options.startScheduler !== false) checkPanel(panel.id, 'schedule', false);
        return json(response, 201, { panel: publicPanel(panel), message: '面板已添加，可点击检测连接' });
      }
      const panelMatch = pathname.match(/^\/api\/panels\/([a-f0-9-]+)(?:\/(check|backup))?$/);
      if (panelMatch) {
        const [, id, action] = panelMatch;
        const panel = panelById(id);
        if (!action && method === 'PUT') {
          if (backupLocks.has(id) || checks.has(id)) throw new HttpError(409, '请等待该面板当前任务完成后再编辑');
          const next = normalizePanel(await jsonBody(request), panel);
          store.mutate(state => { state.panels = state.panels.map(item => item.id === id ? next : item); });
          clients.delete(id);
          if (options.backgroundChecks !== false && options.startScheduler !== false) checkPanel(id, 'schedule', false);
          return json(response, 200, { panel: publicPanel(next), message: '面板设置已更新' });
        }
        if (!action && method === 'DELETE') {
          if (backupLocks.has(id) || checks.has(id)) throw new HttpError(409, '请等待该面板当前任务完成后再删除');
          store.mutate(state => { state.panels = state.panels.filter(item => item.id !== id); });
          clients.delete(id);
          return json(response, 200, { message: '面板已删除，已有备份与任务记录已保留' });
        }
        if (action === 'check' && method === 'POST') {
          const result = await checkPanel(id);
          return json(response, 200, { panel: result, message: result.status.online ? '连接检测完成' : result.status.error });
        }
        if (action === 'backup' && method === 'POST') {
          startBackup(id);
          return json(response, 202, { message: '备份任务已提交，可在任务记录查看结果' });
        }
      }
      if (pathname === '/api/check-all' && method === 'POST') {
        let count = 0;
        for (const panel of store.state.panels) {
          if (checks.has(panel.id)) continue;
          count += 1;
          checkPanel(panel.id);
        }
        return json(response, 202, { message: `已提交 ${count} 个面板的连接检测` });
      }
      if (pathname === '/api/backup-all' && method === 'POST') {
        let count = 0;
        for (const panel of store.state.panels) {
          if (backupLocks.has(panel.id)) continue;
          startBackup(panel.id);
          count += 1;
        }
        return json(response, 202, { message: `已提交 ${count} 个面板的备份任务` });
      }
      const backupMatch = pathname.match(/^\/api\/backups\/([a-f0-9-]+)(?:\/(download))?$/);
      if (backupMatch) {
        const [, id, action] = backupMatch;
        const backup = store.state.backups.find(item => item.id === id);
        if (!backup) throw new HttpError(404, '备份不存在');
        if (action === 'download' && ['GET', 'HEAD'].includes(method)) {
          const kind = url.searchParams.get('kind') || 'db';
          if (!['db', 'config'].includes(kind)) throw new HttpError(400, '下载类型无效');
          const filename = kind === 'db' ? backup.dbFile : backup.configFile;
          if (!filename) throw new HttpError(404, '该备份没有 Xray 配置文件');
          const absolute = store.backupPath(filename);
          if (!fs.existsSync(absolute)) throw new HttpError(404, '备份文件不存在，请检查持久化目录');
          response.writeHead(200, { 'Content-Type': kind === 'db' ? 'application/octet-stream' : 'application/json; charset=utf-8', 'Content-Disposition': `attachment; filename="x-panel-${id}.${kind === 'db' ? 'db' : 'json'}"`, 'Content-Length': fs.statSync(absolute).size, 'Cache-Control': 'no-store' });
          if (method === 'HEAD') return response.end();
          const stream = fs.createReadStream(absolute);
          stream.on('error', () => response.destroy());
          response.on('close', () => stream.destroy());
          return stream.pipe(response);
        }
        if (!action && method === 'DELETE') {
          store.mutate(state => { state.backups = state.backups.filter(item => item.id !== id); });
          try {
            fs.rmSync(store.backupPath(backup.dbFile), { force: true });
            if (backup.configFile) fs.rmSync(store.backupPath(backup.configFile), { force: true });
          } catch { return json(response, 200, { message: '备份记录已删除，但文件清理失败，请检查目录权限' }); }
          return json(response, 200, { message: '备份文件已删除' });
        }
      }
      throw new HttpError(404, '接口不存在');
    } catch (error) {
      if (response.headersSent) return response.destroy();
      const status = error.status || 500;
      if (status === 500) console.error('请求处理失败:', error.message);
      json(response, status, { error: true, message: status === 500 ? '服务处理失败，请查看容器日志' : error.message });
    }
  });
  server.requestTimeout = 60_000;
  server.headersTimeout = 15_000;
  server.keepAliveTimeout = 5_000;

  if (!demo && options.startScheduler !== false) {
    scheduler = setInterval(() => { try { tick(); } catch (error) { console.error('调度失败:', error.message); } }, 30_000);
    scheduler.unref();
    setImmediate(() => { try { tick(); } catch (error) { console.error('初始调度失败:', error.message); } });
    if (options.backgroundChecks !== false) {
      const refresh = () => {
        if (closing) return;
        for (const panel of store.state.panels) {
          try { checkPanel(panel.id, 'schedule', false); } catch (error) { console.error('状态刷新失败:', error.message); }
        }
      };
      statusTimer = setInterval(refresh, 120_000);
      statusTimer.unref();
      setImmediate(refresh);
    }
  }

  return {
    server, store, tick, waitForIdle: () => queue.idle(), stateSnapshot,
    listen(port = options.port ?? Number(process.env.PORT || 3080), host = options.host ?? process.env.HOST ?? '127.0.0.1') {
      return new Promise((resolve, reject) => {
        server.once('error', reject);
        server.listen(port, host, () => { server.off('error', reject); resolve(server.address()); });
      });
    },
    async close() {
      closing = true;
      clearInterval(scheduler);
      clearInterval(statusTimer);
      await queue.idle();
      await Promise.allSettled([...checks.values()]);
      if (!server.listening) return;
      await new Promise((resolve, reject) => { server.close(error => error ? reject(error) : resolve()); server.closeIdleConnections(); });
    },
  };
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  try {
    const app = createApp();
    const address = await app.listen();
    console.log(`X-Panel Manager ${process.env.DEMO_MODE === '1' ? '只读演示' : '已启动'}: http://${address.address}:${address.port}`);
    const shutdown = () => app.close().then(() => process.exit(0)).catch(() => process.exit(1));
    process.once('SIGTERM', shutdown);
    process.once('SIGINT', shutdown);
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}
